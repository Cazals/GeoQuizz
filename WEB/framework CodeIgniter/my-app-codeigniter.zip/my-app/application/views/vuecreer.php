<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	
</head>
<body>

<div id="container">
	<h1>Blablabla ..... </h1>

	<div>
		<p>Ceci est la vue de mon opération Creer.</p>
        
        <p>le produit <?php echo $ref." - ".$nom." - ".$prix ?> a été créé </p>
	</div>

</div>

</body>
</html>



