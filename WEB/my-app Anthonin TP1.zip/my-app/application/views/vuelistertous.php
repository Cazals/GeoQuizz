<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	
</head>
<body>

<div id="container">
	<h1>Blablabla ..... </h1>

	<div>
		<p>Ceci est la vue de mon opération Lister.</p>
        
	</div>
    
    <div>
        <ul>
    <?php
    if($etat == "grille"){
        foreach ($resultat as $ligne)
        {
            echo "<div style='display:inline-block'>";
                echo "<li>".$ligne['id']." - ";
                echo $ligne['titre']." - ";
                echo $ligne['image']." - ";
                echo $ligne['texte']." - ";
                echo $ligne['dateactualite']."</li>";
            echo "</div>";
        }
    }else{
        foreach ($resultat as $ligne)
        {
            echo "<li>".$ligne['id']." - ";
            echo $ligne['titre']." - ";
            echo $ligne['image']." - ";
            echo $ligne['texte']." - ";
            echo $ligne['dateactualite']."</li>";
        }
    }
        
    ?>
            </ul>
    </div>
    }

</div>

</body>
</html>