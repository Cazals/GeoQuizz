<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	
</head>
<body>
<form name="myform" id="myform" method="post">
	<div id="container">
		<h1>Blablabla ..... </h1>

		<div>
			<p>Mon titre:</p>
			<input type="text" id="titre" name="titre">
			<p>Mon image:</p>
			<input type="text" id="image" name="image">
			<p>Mon texte:</p>
			<input type="text" id="texte" name="texte">
			<p>Ma date:</p>
			<input type="date" id="dateactualite" name="dateactualite">

			<input type="submit" id="valider" name="valider" value="valider">

			<p>Ceci est la vue de mon opération Creer.</p>

		</div>

	</div>
<form>
</body>
</html>



