<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Actualite extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$idinfo =trim($this->uri->segment(3)); 
		if($idinfo == "liste" || $idinfo == "grille" || $idinfo ==null){
			$this->load->model('infobdd');
	        $donnees['resultat']=$this->infobdd->listerTous();
	        $donnees['etat'] = $idinfo;
			$this->load->view('vuelistertous',$donnees);
		}else{
			$this->load->model('infobdd');
	        $donnees['resultat']=$this->infobdd->listerUne($idinfo);
	        $donnees['etat'] = "";
			$this->load->view('vuelistertous',$donnees);
		}
	}

	public function new()
	{
		if(($this->input->post('titre')) == null  || ""){
			$this->load->view('vuecreer');
		}else{
			$this->load->model('infobdd');
	        $donnees['resultat']=$this->infobdd->inserer(($this->input->post('titre')), ($this->input->post('image')), ($this->input->post('texte')), ($this->input->post('dateactualite')));
			$this->load->view('vuecreer',$donnees);
		}
	}

	public function supprimer()
	{
		$this->load->model('infobdd');
		$idinfo =$this->uri->segment(3); 
		$donnees['resultat']=$this->infobdd->supprimer($idinfo);
        
        if ($idinfo ==null) {
            $donnees['erreur']="Id produit introuvable";
            $donnees['message']="";
            $donnees['resultat']="";
        } else {
            $donnees['erreur']="";
            $donnees['message']="Produit n° ".$idinfo." supprimé.";
        }
		$this->load->view('vuesupprimer', $donnees);
	}
}
?>
